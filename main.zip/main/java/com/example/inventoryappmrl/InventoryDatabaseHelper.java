package com.example.inventoryappmrl;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final int DATABASE_VERSION = 2;  // Incremented version number to ensure onUpgrade is called

    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_ITEM_QUANTITY = "item_quantity";

    private static final String TAG = "InventoryDatabaseHelper";  // Tag for logging

    public InventoryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_ITEM_NAME + " TEXT,"
                + COLUMN_ITEM_QUANTITY + " INTEGER" + ")";
        db.execSQL(CREATE_INVENTORY_TABLE);
        Log.d(TAG, "Inventory table created successfully.");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "Upgrading database from version " + oldVersion + " to " + newVersion);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
        Log.d(TAG, "Database upgraded and inventory table recreated.");
    }

    public boolean addItem(String itemName, int itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Check if the item already exists
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_INVENTORY + " WHERE " + COLUMN_ITEM_NAME + "=?", new String[]{itemName});

        if (cursor.moveToFirst()) {
            // Item exists, update its quantity
            int currentQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY));
            ContentValues values = new ContentValues();
            values.put(COLUMN_ITEM_QUANTITY, currentQuantity + itemQuantity);

            db.update(TABLE_INVENTORY, values, COLUMN_ITEM_NAME + "=?", new String[]{itemName});
            cursor.close();
            db.close();
            return true; // Item quantity updated successfully
        } else {
            // Item does not exist, create a new entry
            ContentValues values = new ContentValues();
            values.put(COLUMN_ITEM_NAME, itemName);
            values.put(COLUMN_ITEM_QUANTITY, itemQuantity);

            long result = db.insert(TABLE_INVENTORY, null, values);
            cursor.close();
            db.close();
            return result != -1; // returns true if insert is successful
        }
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        Log.d(TAG, "Fetching all items from the inventory table.");
        return db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
    }

    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_INVENTORY, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        Log.d(TAG, "Item deleted with id: " + id);
    }

    public void updateItem(int id, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_QUANTITY, quantity);
        db.update(TABLE_INVENTORY, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        Log.d(TAG, "Item updated with id: " + id + " to quantity: " + quantity);
    }
}
