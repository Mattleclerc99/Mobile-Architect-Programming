package com.example.inventoryappmrl;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;  // Import Log for logging error recording
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private Button btnLogin, btnRegister;
    private UserDatabaseHelper userDatabaseHelper;
    private static final String TAG = "LoginActivity";  // Tag for logging issues

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userDatabaseHelper = new UserDatabaseHelper(this);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                // Logging the inputs for debugging
                Log.d(TAG, "Attempting login with Username: " + username);

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        if (userDatabaseHelper.checkUser(username, password)) {
                            Toast.makeText(LoginActivity.this, "Login successful!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(LoginActivity.this, "Invalid credentials. Please try again.", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error during login", e);
                        Toast.makeText(LoginActivity.this, "An error occurred during login. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                // Logging the inputs for debugging
                Log.d(TAG, "Attempting registration with Username: " + username);

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter both username and password.", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        boolean userExists = userDatabaseHelper.checkUser(username, password);
                        if (userExists) {
                            Toast.makeText(LoginActivity.this, "User already exists. Please login.", Toast.LENGTH_SHORT).show();
                        } else {
                            boolean success = userDatabaseHelper.addUser(username, password);
                            if (success) {
                                Toast.makeText(LoginActivity.this, "Registration successful! Please login.", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(LoginActivity.this, "Registration failed. Please try again.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    } catch (Exception e) {
                        Log.e(TAG, "Error during registration", e);
                        Toast.makeText(LoginActivity.this, "An error occurred during registration. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
