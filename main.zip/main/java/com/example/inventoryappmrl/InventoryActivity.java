package com.example.inventoryappmrl;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private static final String TAG = "InventoryActivity";
    private EditText etNewItemName, etNewItemQuantity;
    private Button btnAddItem;
    private ListView listViewInventory;
    private InventoryDatabaseHelper inventoryDatabaseHelper;
    private InventoryAdapter adapter;
    private ArrayList<InventoryItem> inventoryList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inventoryDatabaseHelper = new InventoryDatabaseHelper(this);

        etNewItemName = findViewById(R.id.etNewItemName);
        etNewItemQuantity = findViewById(R.id.etNewItemQuantity);
        btnAddItem = findViewById(R.id.btnAddItem);
        listViewInventory = findViewById(R.id.listViewInventory);

        inventoryList = new ArrayList<>();
        adapter = new InventoryAdapter();
        listViewInventory.setAdapter(adapter);

        btnAddItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String itemName = etNewItemName.getText().toString();
                String itemQuantity = etNewItemQuantity.getText().toString();

                if (!itemName.isEmpty() && !itemQuantity.isEmpty()) {
                    int quantity = Integer.parseInt(itemQuantity);
                    boolean success = inventoryDatabaseHelper.addItem(itemName, quantity);
                    if (success) {
                        Toast.makeText(InventoryActivity.this, "Item added successfully!", Toast.LENGTH_SHORT).show();
                        loadInventoryData();  // Refresh the inventory list
                    } else {
                        Toast.makeText(InventoryActivity.this, "Failed to add item. Please try again.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(InventoryActivity.this, "Please enter item name and quantity.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Load and display the inventory data when the activity starts
        loadInventoryData();
    }

    private void loadInventoryData() {
        Cursor cursor = inventoryDatabaseHelper.getAllItems();
        inventoryList.clear();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow("item_quantity"));

                InventoryItem item = new InventoryItem(id, itemName, quantity);
                inventoryList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private class InventoryAdapter extends ArrayAdapter<InventoryItem> {

        InventoryAdapter() {
            super(InventoryActivity.this, 0, inventoryList);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_inventory, parent, false);
            }

            InventoryItem item = getItem(position);

            TextView tvItemName = convertView.findViewById(R.id.tvItemName);
            TextView tvItemQuantity = convertView.findViewById(R.id.tvItemQuantity);
            Button btnRemoveItem = convertView.findViewById(R.id.btnRemoveItem);

            tvItemName.setText(item.getItemName());
            tvItemQuantity.setText("Quantity: " + item.getItemQuantity());

            btnRemoveItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showQuantitySplitDialog(item);
                }
            });

            return convertView;
        }
    }

    private void showQuantitySplitDialog(InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_split_quantity, null);
        builder.setView(dialogView);

        TextView tvDialogItemName = dialogView.findViewById(R.id.tvDialogItemName);
        SeekBar sbQuantity = dialogView.findViewById(R.id.sbQuantity);
        TextView tvSelectedQuantity = dialogView.findViewById(R.id.tvSelectedQuantity);

        tvDialogItemName.setText("Remove quantity from: " + item.getItemName());
        sbQuantity.setMax(item.getItemQuantity());
        sbQuantity.setProgress(0);
        tvSelectedQuantity.setText("0");

        sbQuantity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvSelectedQuantity.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        builder.setPositiveButton("Remove", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                int quantityToRemove = sbQuantity.getProgress();
                if (quantityToRemove > 0) {
                    removeItemQuantity(item, quantityToRemove);
                }
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void removeItemQuantity(InventoryItem item, int quantityToRemove) {
        if (item.getItemQuantity() > quantityToRemove) {
            // Reduce the quantity
            inventoryDatabaseHelper.updateItem(item.getId(), item.getItemQuantity() - quantityToRemove);
            Toast.makeText(this, "Removed " + quantityToRemove + " of " + item.getItemName(), Toast.LENGTH_SHORT).show();
        } else {
            // Remove the item completely
            inventoryDatabaseHelper.deleteItem(item.getId());
            Toast.makeText(this, item.getItemName() + " removed from inventory.", Toast.LENGTH_SHORT).show();
        }
        loadInventoryData();  // Refresh the inventory list
    }

    private class InventoryItem {
        private int id;
        private String itemName;
        private int itemQuantity;

        public InventoryItem(int id, String itemName, int itemQuantity) {
            this.id = id;
            this.itemName = itemName;
            this.itemQuantity = itemQuantity;
        }

        public int getId() {
            return id;
        }

        public String getItemName() {
            return itemName;
        }

        public int getItemQuantity() {
            return itemQuantity;
        }
    }
}
